/** Automatically generated file. DO NOT MODIFY */
package automagic.tripcompanion;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}